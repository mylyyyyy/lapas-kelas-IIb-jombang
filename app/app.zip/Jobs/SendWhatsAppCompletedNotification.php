<?php

namespace App\Jobs;

use App\Models\Kunjungan;
use App\Services\WhatsAppService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendWhatsAppCompletedNotification implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $kunjungan;

    /**
     * Create a new job instance.
     */
    public function __construct(Kunjungan $kunjungan)
    {
        $this->kunjungan = $kunjungan;
    }

    /**
     * Execute the job.
     */
    public $tries = 5;

    public function backoff(): array
    {
        return [60, 120, 300, 900];
    }

    public function handle(WhatsAppService $whatsAppService): void
    {
        if (empty($this->kunjungan->no_wa_pengunjung)) {
            Log::warning("Kunjungan ID: {$this->kunjungan->id} has no WhatsApp number to send completion notification.");
            return;
        }

        $original = $this->kunjungan->no_wa_pengunjung;
        Log::info("CompletedJob: Preparing to send WA for Kunjungan ID: {$this->kunjungan->id}, original: {$original}");

        $normalized = $whatsAppService->formatPhoneNumber($original);
        Log::info("CompletedJob: Normalized WA number: {$normalized}");

        $response = $whatsAppService->sendCompleted($this->kunjungan);

            $ok = (!array_key_exists('status', $decoded) || $decoded['status'] == true) && (method_exists($response, 'successful') ? $response->successful() : true);
            $reason = $decoded['reason'] ?? null;
            $requestId = $decoded['requestid'] ?? null;

        if ($ok) {
            \Illuminate\Support\Facades\Cache::forget("wa_failures:{$normalized}");
            $this->kunjungan->updateNotificationLog('whatsapp', 'sent');
            Log::info("CompletedJob: WA sent for Kunjungan ID: {$this->kunjungan->id}. Response: " . ($response ? $response->body() : 'no response'));
            return;
        }

        $key = "wa_failures:{$normalized}";
        $count = (int) (\Illuminate\Support\Facades\Cache::get($key, 0) + 1);
        \Illuminate\Support\Facades\Cache::put($key, $count, 60 * 60);

        $threshold = 3;
        if ($count < $threshold) {
            Log::warning("CompletedJob: WA provider rejected for Kunjungan ID: {$this->kunjungan->id}. Attempt {$count}/{$threshold}. Reason: " . ($reason ?? 'unknown') . ". RequestId: " . ($requestId ?? 'n/a'));
            throw new \Exception('WA provider rejected: ' . ($reason ?? 'unknown'));
        }

        $this->kunjungan->updateNotificationLog('whatsapp', 'failed', $reason ?? 'Repeated failure');
        $alertKey = "wa_alerted:{$normalized}";
        if (!\Illuminate\Support\Facades\Cache::get($alertKey)) {
            try {
                \Illuminate\Support\Facades\Mail::to(env('ADMIN_EMAIL'))->send(new \App\Mail\WhatsAppProviderFailure([
                    'kunjungan_id' => $this->kunjungan->id,
                    'target' => $normalized,
                    'original' => $original,
                    'reason' => $reason,
                    'requestid' => $requestId,
                    'response' => $response ? ($response->body() ?? null) : null,
                    'attempts' => $count,
                ]));
                \Illuminate\Support\Facades\Cache::put($alertKey, true, 24 * 60 * 60);
                Log::error("CompletedJob: Admin alerted for repeated WA failures for target {$normalized} (Kunjungan ID: {$this->kunjungan->id}). Attempts: {$count}");
            } catch (\Exception $e) {
                Log::error("CompletedJob: Failed to send admin alert for Kunjungan ID: {$this->kunjungan->id}. Error: " . $e->getMessage());
            }
        }

        Log::error("CompletedJob: WA FAILED repeatedly for Kunjungan ID: {$this->kunjungan->id}. Attempts: {$count}. Reason: " . ($reason ?? 'unknown'));
        $this->fail(new \Exception('Repeated WA provider rejection: ' . ($reason ?? 'unknown')));
    }
}
